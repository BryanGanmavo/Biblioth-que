<?php
function find_all_ouvrage(): array{
    $ouvrages=[
        ['id'=>1,'code'=>uniqid(),'titre'=>'Le Cid','date_edition'=>'1636'],
        ['id'=>2,'code'=>uniqid(),'titre'=>"Le Monde d'hier",'date_edition'=>'1942'],
        ['id'=>3,'code'=>uniqid(),'titre'=>'Atlas mondial','date_edition'=>'2022'],
        ['id'=>4,'code'=>uniqid(),'titre'=>"Harry Potter à l'école des sorciers",'date_edition'=>'1997']
    ];
    return $ouvrages;
}
function find_all_author(): array{
    $authors=[
        ['id'=>1,'nom'=>'Pierre Corneille'],
        ['id'=>2,'nom'=>'Stefan Zweig'],
        ['id'=>3,'nom'=>'Patrick Mérienne'],
        ['id'=>4,'nom'=>'J.K. Rowling']
    ];
    return $authors;
}
function find_all_copy(): array{
    $copies=[
        ['id'=>1,'code'=>uniqid(),"date_d_enregistrement"=>'30 Janvier 2021'],
        ['id'=>2,'code'=>uniqid(),"date_d_enregistrement"=>'27 Août 2022'],
        ['id'=>3,'code'=>uniqid(),"date_d_enregistrement"=>'17 Juin 2022'],
        ['id'=>4,'code'=>uniqid(),"date_d_enregistrement"=>'13 Septembre 2021']
    ];
    return $copies;
}
function find_all_rayon():array{
    $rayons=[
        ['id'=>1,'categorie'=>'Littérature'],
        ['id'=>2,'categorie'=>'Histoire'],
        ['id'=>3,'categorie'=>'Géogrpahie'],
        ['id'=>4,'categorie'=>'Fiction']
    ];
    return $rayons;
}
function find_all_adherent():array{
    $adherents=[
        ['id'=>1,'nom'=>'DIOP','prenom'=>'Youssouf','telephone'=>'771894563'],
        ['id'=>2,'nom'=>'DIAW','prenom'=>'Mohammed','telephone'=>'771784573'],
        ['id'=>3,'nom'=>'COULIBALY','prenom'=>'Paul','telephone'=>'775677863'],
        ['id'=>4,'nom'=>'FATOU','prenom'=>'Viviane','telephone'=>'764567893'],
        ['id'=>5,'nom'=>'SANTOS','prenom'=>'Pierrot','telephone'=>'785906563']
    ];
    return $adherents;
}
function find_all_loan():array{
    $loans=[
        ['id'=>1,'date'=>'15 Juin 2022','date_de_retour_prevu'=>'30 Juin 2022','date_de_retour_relle'=>'28 Juin 2022','exemplaire_id'=>1,'adherent_id'=>1],
        ['id'=>2,'date'=>'15 Novembre 2022','date_de_retour_prevu'=>'30 Novembre 2022','date_de_retour_relle'=>'26 Novembre 2022','exemplaire_id'=>1,'adherent_id'=>2],
        ['id'=>1,'date'=>'21 Novembre 2022','date_de_retour_prevu'=>'6 Novembre 2022','date_de_retour_relle'=>'-','exemplaire_id'=>2,'adherent_id'=>3],
        ['id'=>1,'date'=>'17 Juin 2022','date_de_retour_prevu'=>'2 Juillet 2022','date_de_retour_relle'=>'2 Juillet 2022','exemplaire_id'=>3,'adherent_id'=>4],
        ['id'=>1,'date'=>'9 Décembre 2022','date_de_retour_prevu'=>'24 Décembre 2022','date_de_retour_relle'=>'25 Décembre 2021','exemplaire_id'=>4,'adherent_id'=>5]
    ];
    return $adherents;
}


?>