<?php
require_once("../model/bibliotheque.model.php");
$ouvrage=find_all_ouvrage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/style.css">
    <title>Document</title>
</head>
<body>
    <div class="conteneur">
        <div class="classe">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Code</th>
                    <th>Titre</th>
                    <th>Date d'édition</th>
                </tr>
                <?php foreach($ouvrage as $ouvrages):?>
                <tr>
                    <td><?= $ouvrages['id']?></td>
                    <td><?= $ouvrages['code']?></td>
                    <td><?= $ouvrages['titre']?></td>
                    <td><?= $ouvrages['date_edition']?></td>
                </tr>
                <?php endforeach ?>
            </table>
        </div>
    </div>
</body>
</html>